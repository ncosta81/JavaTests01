public class Comentarios {
    public static void main(String[] args) {
        //Línea comentada.
        String canal, curso, proposito;
        canal = "Informacion";
        curso = "Java";
        proposito = "Aprender a comentar";

        /*System.out.println("Nombre del canal: "+ canal);
        System.out.println("Nombre del curso: "+ curso);*/
        System.out.println("Propósito: "+ proposito);
    }
}
