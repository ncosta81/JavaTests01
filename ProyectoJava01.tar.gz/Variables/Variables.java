package Variables;

public class Variables {

    public static void main(String[] args) {
        String nombre = "Nathaniel";
        int valor = 100;
        double valor2 = 10.5;
        char letra1 = 'B';
        boolean esEstudiante = true;

        System.out.println(nombre);
        System.out.println(valor);
        System.out.println(valor2);
        System.out.println(letra1);
        System.out.println(esEstudiante);
    }
}