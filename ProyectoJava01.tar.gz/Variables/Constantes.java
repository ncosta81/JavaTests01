package Variables;

public class Constantes {
    static void main(String[] args) {
        final int valor = 50;
        System.out.println("Valor: "+valor);
    }
}
