package Variables;

public class Var_Java {
    static void main(String[] args) {
        var nombre = "Variable01";

        System.out.println(nombre);

    }
}
