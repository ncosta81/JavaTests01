package Condicionales;

public class Condicional_or {
    static void main(String[] args) {
        boolean domingo = true;
        boolean vacaciones = true;

        //Ingreso de datos
        if(domingo || vacaciones){
            System.out.println("No trabajes");
        }else{
            System.out.println("A currar");
        }



    }
}
