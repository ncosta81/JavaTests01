package Operadores;

public class Operadores_Comparacion {
    static void main(String[] args) {
        int valor1 = 90, valor2 = 50;

        //Igualdad.
        System.out.println(valor1==valor2);
        //Desigualdad.
        System.out.println(valor1!=valor2);
        //Mayor.
        System.out.println(valor1>valor2);
        //Menor.
        System.out.println(valor1<valor2);
        //Mayor o igual.
        System.out.println(valor1>=valor2);
        //Menor o igual.
        System.out.println(valor1<=valor2);
    }
}
