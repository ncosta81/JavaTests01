package Operadores;

public class Operadores_Logicos {
    static void main(String[] args) {
        boolean a = true, b = false, c = false;

        //Operador AND.
        System.out.println(a && b);

        //Operador OR.
        System.out.println(a || b || c);

        //Operador XOR.
        System.out.println(a ^ b ^c);
    }
}
