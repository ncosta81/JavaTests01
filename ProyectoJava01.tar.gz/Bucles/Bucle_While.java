package Bucles;

public class Bucle_While {
    static void main(String[] args) {
        int f=0;

        //Bucle while.
        while (f<5){
            System.out.println(f++);
        }
    }
}
