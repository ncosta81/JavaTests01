package Bucles;

public class Bucle_For {
    static void main(String[] args) {

        //Bucle ascendente.
        for (int f=0; f<=10; f++){
            System.out.println("f: "+f);
        }
        System.out.println(" ");

        //Bucle descendente.
        for (int g=10; g>=0; g--){
            System.out.println("g: "+g);
        }
    }
}
